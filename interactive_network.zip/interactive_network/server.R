# server.R
library(shiny)
library(networkD3)

####################################

node <- read.csv("node3_d3.csv", header=T, as.is=T)
link <- read.csv("edge3.csv", header=T, as.is=T)

node$type[node$type==1] <- "Retail"
node$type[node$type==2] <- "Wholesale"
node$type[node$type==3] <- "PPNR"
node$type[node$type==4] <- "Expected Loss"


el <- data.frame(from=as.numeric(factor(link$from, levels=node$id))-1, 
                 to=as.numeric(factor(link$to, levels=node$id))-1 )
                 
nl <- cbind(idn=factor(node$id, levels=node$id), node) 

    
server <- function(input, output) {



output$force1 <- renderForceNetwork({

 forceNetwork(Links = el, Nodes = nl, Source="from", Target="to",
colourScale=JS("d3.scale.category10()"),
               NodeID = "name", Group = "type", linkWidth = 1,
               linkColour = "#afafaf", fontSize=12, zoom=T, legend=T,
               Nodesize=5, opacity = 0.8, charge=-300, 
               width = 1000, height = 1000, arrows=T)


  })
  output$force2 <- renderForceNetwork({

 forceNetwork(Links = el, Nodes = nl, Source="from", Target="to",
colourScale=JS("d3.scale.category10()"),
               NodeID = "name", Group = "name2", linkWidth = 1,
               linkColour = "#afafaf", fontSize=12, zoom=T, legend=T,
               Nodesize=5, opacity = 0.8, charge=-300, 
               width = 1000, height = 1000, arrows=T)


  })


}
