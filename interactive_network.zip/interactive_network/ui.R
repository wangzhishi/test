## ui.R

library(shiny)
library(networkD3)


ui <- shinyUI(fluidPage(


titlePanel("Interactive Demo of Model Inventory Network"),


 fluidRow(
      column(width=12,

    mainPanel(

      tabsetPanel(

        tabPanel("By Model Type", forceNetworkOutput("force1")),

        tabPanel("By Modeling Technique", forceNetworkOutput("force2"))

      )

    )
    )

  )

))
